import React from 'react';
import loader from './45.gif';

export default function Loader() {
    return (
        <img src={loader} alt=""/>
    )
}
